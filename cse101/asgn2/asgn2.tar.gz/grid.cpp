#include "grid.h"
#include <cassert>

// Constants ---------------------------------------------------------
Grid::weight_t const Grid::NOEDGE = -1;
Grid::weight_t const Grid::PATH = 1;
std::string const P3_NODE = "255 255 255\n";
std::string const P3_EDGE = "255 255 255\n";
std::string const P3_WALL = "0 0 0\n";
std::string const P3_PATH = "255 0 0\n";

// Definitions -------------------------------------------------------
std::ostream& operator<<(std::ostream &out, Point const &p) {
    return out << '(' << p.x << ',' << p.y << ')';
}

Grid::Node::Node() 
{
    // TODO
	std::fill(weights.begin(), weights.end(), NOEDGE);
}

Grid::Grid(unsigned height, unsigned width)
{
    // TODO
    std::vector<std::vector<Node>> nodes_;
    for (unsigned h = 0; h < height; h++)
    {
	    std::vector<Node> row;
	    nodes_.push_back(row);
	    for (unsigned w = 0; w < width; w++)
	    {
		    Node n = Node();
		    row.push_back(n);
	    }
    }
}
unsigned Grid::getHeight() const 
{
    // TODO
    return nodes_.size();
}

unsigned Grid::getWidth() const 
{
    // TODO
    return nodes_.front().size();
}

Grid::weight_t Grid::getEdge(Point const &a, Point const &b) const 
{
    // TODO
    
    //Right
    if ((a.x + 1 == b.x || a.x - 1 == b.x) && (a.y == b.y))
    {
	    return nodes_[a.x][a.y].weights[1];
    }
    
    //Down
    if ((a.y + 1 == b.y || a.y - 1 == b.y) && (a.x == b.x))
    {
	    return nodes_[a.x][a.y].weights[0];
    }
    else
    {
	    return 0;
    }

}

bool Grid::setEdge(Point const &a, Point const &b, weight_t weight) 
{
    // TODO
    //Right
    if ((a.x + 1 == b.x || a.x - 1 == b.x) && (a.y == b.y))
    {
            nodes_[a.x][a.y].weights[1] = weight;
	    return true;
    }

    //Down
    if ((a.y + 1 == b.y || a.y - 1 == b.y) && (a.x == b.x))
    {
            nodes_[a.x][a.y].weights[0] = weight;
	    return true;
    }
    else
    {
            return false;
    }
}

void Grid::draw(std::ostream &out) const 
{
    // TODO
    unsigned heightOfPic = (getHeight() * 2) + 1;
    unsigned widthOfPic = (getWidth() * 2) + 1;
    out << "P3" << std::endl;
    out << widthOfPic << " " << heightOfPic << std::endl;
    out << "255" << std::endl;

    //drawing the top border
    for (unsigned i = 0; i < widthOfPic; i++)
    {
	    out << P3_WALL;
    }
    
    //Drawing the middle bits
    for (unsigned col = 0; col < getWidth(); col++)
    {
	    for (unsigned row = 0; row < getHeight(); row++)
	    {
		    //Node drawing
		    out << P3_NODE;

		    //Right Edge Drawing
		    weight_t rightEdge = getEdge({col, row}, {col + 1, row});

		    if (weight_t == NOEDGE)
		    {
			    out << P3_WALL;
		    }
		    else if (weight_t != NOEDGE)
		    {
			    out << P3_EDGE;
		    }

		    //Down Edge Drawing
		    weight_t downEdge = getEdge({col, row}, {col, row + 1});
		    if (weight_t == NOEDGE)
                    {
                            out << P3_WALL;
                    }
                    else if (weight_t != NOEDGE)
                    {
                            out << P3_EDGE;
                    }
	    }
    }
    return;
}


void Grid::serialize(std::ostream &out) const {
    // TODO
    return;
}


Grid Grid::load(std::istream &in) {
    // TODO
	Grid g  = Grid(1, 1);
	return g;
}
