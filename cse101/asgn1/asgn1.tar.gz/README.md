
# Assignment 1: Can you C++?

## Short description:
	This program is a sorter that will sort a linked list given a beginning and an end.

## Build
	type "make" on the command line with the Makefile provided in the directory

## Running
	Run the test using ./sort_test

## Cleaning
	Alternatively type "clean" on the command line, using Makefile provided

## Errors Handling:

## Included Files
	README
	Makefile
	sort.h
	test.cpp

## Credit
	Previous assignments from previous classes

